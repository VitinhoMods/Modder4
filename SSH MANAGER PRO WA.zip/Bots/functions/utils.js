/**
 * Gera uma senha numérica aleatória com o comprimento especificado
 * @param {number} length - Comprimento da senha
 * @returns {string} Senha numérica aleatória
 */
function generateRandomPassword(length = 4) {
  // Apenas números (0-9)
  const chars = '0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Gera um nome de usuário aleatório com o comprimento especificado
 * @param {number} length - Comprimento do nome de usuário
 * @returns {string} Nome de usuário aleatório
 */
function generateRandomUsername(length = 5) {
  // Combinação de letras minúsculas e números (evitando caracteres ambíguos)
  const chars = 'abcdefghijkmnopqrstuvwxyz23456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

module.exports = {
  generateRandomUsername,
  generateRandomPassword
};