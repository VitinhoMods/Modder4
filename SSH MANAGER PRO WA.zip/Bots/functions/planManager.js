const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

class PlanManager {
  constructor() {
    this.plansFile = path.join(__dirname, '../data/plans.json');
    this.plans = this.loadPlans();
  }

  loadPlans() {
    try {
      if (fs.existsSync(this.plansFile)) {
        return JSON.parse(fs.readFileSync(this.plansFile, 'utf8'));
      }
      return [];
    } catch (error) {
      console.error('Error loading plans:', error);
      return [];
    }
  }

  savePlans() {
    fs.writeFileSync(this.plansFile, JSON.stringify(this.plans, null, 2));
  }

  getPlans() {
    return this.plans;
  }

  getPlanById(planId) {
    return this.plans.find(plan => plan.id === planId);
  }

  addPlan(planData) {
    try {
      const plan = {
        id: uuidv4(),
        name: planData.name,
        days: planData.days,
        price: planData.price,
        createdAt: new Date().toISOString()
      };

      this.plans.push(plan);
      this.savePlans();

      return {
        success: true,
        message: `✅ Plano *${plan.name}* (${plan.days} dias por ${plan.price} Reais) adicionado com sucesso!`,
        planId: plan.id
      };
    } catch (error) {
      return {
        success: false,
        message: `❌ Erro ao adicionar plano: ${error.message}`
      };
    }
  }

  updatePlan(planId, planData) {
    try {
      const planIndex = this.plans.findIndex(p => p.id === planId);

      if (planIndex === -1) {
        return {
          success: false,
          message: '❌ Plano não encontrado'
        };
      }

      // Atualizar plano existente
      this.plans[planIndex] = {
        ...this.plans[planIndex],
        ...planData,
        updatedAt: new Date().toISOString()
      };

      this.savePlans();

      return {
        success: true,
        message: `✅ Plano *${this.plans[planIndex].name}* atualizado com sucesso!`
      };
    } catch (error) {
      return {
        success: false,
        message: `❌ Erro ao atualizar plano: ${error.message}`
      };
    }
  }

  deletePlan(planId) {
    try {
      const planIndex = this.plans.findIndex(p => p.id === planId);

      if (planIndex === -1) {
        return {
          success: false,
          message: '❌ Plano não encontrado'
        };
      }

      const planName = this.plans[planIndex].name;
      this.plans.splice(planIndex, 1);
      this.savePlans();

      return {
        success: true,
        message: `✅ Plano *${planName}* removido com sucesso!`
      };
    } catch (error) {
      return {
        success: false,
        message: `❌ Erro ao remover plano: ${error.message}`
      };
    }
  }
}

module.exports = new PlanManager();