const fs = require('fs');
const path = require('path');

class UserManager {
  constructor() {
    this.ignoredUsers = new Map();
    this.filePath = path.join(__dirname, '../../data/ignoredUsers.json');
    this.load();
    this.startCleanupInterval();
  }

  // Carrega usuários ignorados do arquivo
  load() {
    if (fs.existsSync(this.filePath)) {
      const data = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      data.forEach(([user, time]) => this.ignoredUsers.set(user, time));
    }
  }

  // Salva usuários ignorados no arquivo
  save() {
    const data = Array.from(this.ignoredUsers.entries());
    fs.writeFileSync(this.filePath, JSON.stringify(data));
  }

  // Adiciona um usuário à lista de ignorados
  ignoreUser(userId, hours = 24) {
    const expireTime = Date.now() + (hours * 3600 * 1000);
    this.ignoredUsers.set(userId, expireTime);
    this.save();
  }

  // Verifica se um usuário está ignorado
  isUserIgnored(userId) {
    if (!this.ignoredUsers.has(userId)) return false;

    const expireTime = this.ignoredUsers.get(userId);
    if (Date.now() > expireTime) {
      this.ignoredUsers.delete(userId);
      this.save();
      return false;
    }

    return true;
  }

  // Limpeza automática de usuários expirados
  startCleanupInterval() {
    setInterval(() => {
      const now = Date.now();
      this.ignoredUsers.forEach((expireTime, userId) => {
        if (now > expireTime) {
          this.ignoredUsers.delete(userId);
        }
      });
      this.save();
    }, 3600000); // 1 hora
  }
}

module.exports = new UserManager();