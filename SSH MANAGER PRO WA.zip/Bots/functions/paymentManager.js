const { MercadoPagoConfig, Payment } = require('mercadopago');
const path = require('path');
const fs = require('fs');

class PaymentManager {
  constructor() {
    // Configuração do Mercado Pago (SDK v2.x)
    const client = new MercadoPagoConfig({
      accessToken: 'APP_USR-4772072347194627-123011-a18ca39a84bb892d2e16815a1dc7e279-1609327064', // Seu token
    });

    this.paymentClient = new Payment(client); // Cliente para pagamentos
    this.paymentsFile = path.join(__dirname, '../data/payments.json');
    this.payments = this.loadPayments();
    this.pendingPayments = new Map(); // Armazena pagamentos pendentes
  }

  // Carrega os pagamentos do arquivo JSON
  loadPayments() {
    try {
      if (fs.existsSync(this.paymentsFile)) {
        return JSON.parse(fs.readFileSync(this.paymentsFile, 'utf8'));
      }
      return [];
    } catch (error) {
      console.error('Erro ao carregar pagamentos:', error);
      return [];
    }
  }

  // Salva os pagamentos no arquivo JSON
  savePayments() {
    try {
      fs.writeFileSync(this.paymentsFile, JSON.stringify(this.payments, null, 2));
    } catch (error) {
      console.error('Erro ao salvar pagamentos:', error);
    }
  }

  // Cria um pagamento PIX
  async createPixPayment(plan, userEmail) {
    try {
      // Validação básica do email
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userEmail)) {
        throw new Error('Formato de email inválido!');
      }

      // Dados do pagamento
      const paymentData = {
        transaction_amount: plan.price,
        description: `Plano ${plan.name} - ${plan.days} dias de VPN`,
        payment_method_id: 'pix',
        payer: {
          email: userEmail,
        },
      };

      // Cria o pagamento via SDK v2.x
      const response = await this.paymentClient.create({ body: paymentData });

      // Verifica se a resposta é válida
      if (!response.point_of_interaction?.transaction_data) {
        throw new Error('Resposta do Mercado Pago inválida!');
      }

      // Extrai dados do PIX
      const transactionData = response.point_of_interaction.transaction_data;

      // Dados para salvar localmente
      const payment = {
        id: response.id,
        status: 'pending', // Status inicial
        qr_code: transactionData.qr_code,
        qr_code_base64: transactionData.qr_code_base64,
        ticket_url: transactionData.ticket_url,
        pix_code: transactionData.qr_code,
        expiration: Date.now() + 15 * 60 * 1000, // 15 minutos
        planId: plan.id,
        userEmail,
        created: new Date().toISOString(),
      };

      // Armazena o pagamento como pendente
      this.pendingPayments.set(payment.id, payment);
      this.payments.push(payment);
      this.savePayments();

      return {
        success: true,
        payment,
      };
    } catch (error) {
      console.error('Erro ao criar pagamento:', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  // Verifica o status do pagamento no Mercado Pago
  async checkPaymentStatus(paymentId) {
    try {
      const payment = await this.paymentClient.get({ id: paymentId });
      return payment.status === 'approved'; // Retorna true se o pagamento foi aprovado
    } catch (error) {
      console.error('Erro ao verificar pagamento:', error);
      return false;
    }
  }

  // Obtém um pagamento pelo ID
  getPayment(paymentId) {
    return this.payments.find((p) => p.id === paymentId);
  }

  // Remove um pagamento pendente
  removePendingPayment(paymentId) {
    this.pendingPayments.delete(paymentId);
  }
}

module.exports = new PaymentManager();