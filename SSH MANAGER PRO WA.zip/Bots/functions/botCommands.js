const sshManager = require('./sshManager');
const planManager = require('./planManager');
const trialManager = require('./trialManager');
const paymentManager = require('./paymentManager'); // Importação do gerenciador de pagamentos
const { generateRandomUsername } = require('./utils');

// Objeto para controlar conversações ativas
const conversations = {};

// Objeto para armazenar usuários que selecionaram um plano
const userSelections = {};

const isAdmin = (phoneNumber) => {
  // Lista de números de administrador (você pode modificar conforme necessário)
  const adminNumbers = ['558584252771', '5521888888888'];
  // Extrair número do JID (exemplo: 551199999999@s.whatsapp.net)
  const userPhone = phoneNumber.split('@')[0];
  return adminNumbers.includes(userPhone);
};

const commands = {
  // Verifica se há uma conversa ativa
  isInConversation(jid) {
    return !!conversations[jid];
  },

    async testeGratis(msg, sock) {
    const jid = msg.key.remoteJid;

    // Verificar se está no cooldown
    if (!trialManager.canRequestTrial(jid)) {
      const remaining = trialManager.getRemainingCooldown(jid);
      const hours = Math.ceil(remaining / (60 * 60 * 1000));
      return `⏳ Você só pode solicitar um novo teste grátis a cada 48 horas.\nTente novamente em ${hours} horas.`;
    }

    // Criar conta de teste
    const server = sshManager.getAvailableServer();
    if (!server) return '❌ Nenhum servidor disponível no momento';

    const username = generateRandomUsername(5);
    const result = await sshManager.createTrialUser(username, server.id);

    if (result.success) {
      trialManager.registerTrial(jid);

      return `✅ *TESTE GRATUITO ATIVADO!*\n
👤 Usuário: ${result.details.username}
🔑 Senha: ${result.details.password}
📡 Servidor: ${result.details.ip}:${result.details.port}
⏳ Validade: 1 hora\n
⚠️ Após 1 hora, o acesso será revogado automaticamente!`;
    }
    return result.message;
  },


  // Processa mensagens em conversas ativas
  async processMessage(msg, sock) {
    const jid = msg.key.remoteJid;
    const body = msg.message.conversation 
      || msg.message.extendedTextMessage?.text 
      || '';

    if (!conversations[jid]) return;

    const conversation = conversations[jid];

    try {
      // Processar as conversações para adicionar servidor
      if (conversation.type === 'addserver') {
        await this.processAddServerConversation(conversation, body, jid, sock);
      }
      // Processar as conversações para adicionar plano
      else if (conversation.type === 'addplano') {
        await this.processAddPlanConversation(conversation, body, jid, sock);
      }
      // Processar as conversações para pagamento
      else if (conversation.type === 'payment') {
        await this.processPaymentConversation(conversation, body, jid, sock);
      }
    } catch (error) {
      delete conversations[jid];
      await sock.sendMessage(jid, { text: `❌ Erro: ${error.message}\nOperação cancelada` });
    }
  },

  // Função para processar o pagamento
  async processPaymentConversation(conversation, body, jid, sock) {
    switch (conversation.step) {
      case 'email':
        const email = body.trim();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          throw new Error('Formato de email inválido!');
        }

        // Cria o pagamento PIX
        const paymentResult = await paymentManager.createPixPayment(
          conversation.data.selectedPlan, 
          email
        );

        if (!paymentResult.success) {
          throw new Error('Falha ao gerar pagamento');
        }

        const payment = paymentResult.payment;

        // Mensagem formatada com os dados do PIX
        const paymentMessage = `💰 *PAGAMENTO VIA PIX* 💰\n
Valor: R$ ${conversation.data.selectedPlan.price},00
Destinatário: SUA_EMPRESA\n
🔵 *QR Code PIX*:
${payment.qr_code}\n
📟 *Código PIX (Copiar e Colar)*:
${payment.pix_code}\n
⏳ Este PIX expira em 15 minutos!\n
Após o pagamento, você receberá suas credenciais automaticamente.`;

        // Envia imagem do QR Code se estiver disponível
        if (payment.qr_code_base64) {
          await sock.sendMessage(jid, { 
            image: Buffer.from(payment.qr_code_base64, 'base64'),
            caption: paymentMessage
          });
        } else {
          await sock.sendMessage(jid, { text: paymentMessage });
        }

        // Inicia a verificação periódica do pagamento
        const checkInterval = setInterval(async () => {
          const isPaid = await paymentManager.checkPaymentStatus(payment.id);

          if (isPaid) {
            clearInterval(checkInterval); // Para a verificação
            paymentManager.removePendingPayment(payment.id); // Remove da lista de pendentes

            // Cria a conta VPN
            const server = sshManager.getAvailableServer();
            if (!server) {
              throw new Error('Nenhum servidor disponível');
            }

            const username = generateRandomUsername(5);
            const result = await sshManager.createSSHUser(username, conversation.data.selectedPlan.days, server.id);

            if (result.success) {
              const credentials = `✅ *PAGAMENTO CONFIRMADO!* 🎉\n
Aqui estão suas credenciais:\n
👤 Usuário: ${username}
🔑 Senha: ${result.details.password}
📡 Servidor: ${result.details.ip}:${result.details.port}
⏳ Validade: ${result.details.expiration}\n
Aproveite sua VPN!`;

              await sock.sendMessage(jid, { text: credentials });
            } else {
              await sock.sendMessage(jid, { text: '❌ Erro ao criar conta após pagamento' });
            }
          }
        }, 30000); // Verifica a cada 30 segundos

        delete conversations[jid];
        break;

      default:
        delete conversations[jid];
        await sock.sendMessage(jid, { text: '❌ Processo de pagamento cancelado' });
    }
  },

  async processAddServerConversation(conversation, body, jid, sock) {
    switch (conversation.step) {
      case 'name':
        conversation.data.name = body.trim();
        conversation.step = 'ip';
        await sock.sendMessage(jid, { text: '📡 Agora digite o *IP do servidor*:' });
        break;

      case 'ip':
        const ip = body.trim();
        if (!/^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(ip)) {
          throw new Error('Formato de IP inválido!');
        }
        conversation.data.ip = ip;
        conversation.step = 'port';
        await sock.sendMessage(jid, { text: '🔌 Digite a *porta SSH* (padrão 22):' });
        break;

      case 'port':
        const port = body.trim() || '22';
        if (!/^\d+$/.test(port)) {
          throw new Error('Porta inválida! Use apenas números');
        }
        conversation.data.port = parseInt(port);
        conversation.step = 'user';
        await sock.sendMessage(jid, { text: '👤 Digite o *usuário SSH*:' });
        break;

      case 'user':
        conversation.data.user = body.trim();
        conversation.step = 'password';
        await sock.sendMessage(jid, { text: '🔑 Digite a *senha do usuário*:' });
        break;

      case 'password':
        conversation.data.password = body.trim();
        conversation.step = 'confirm';
        const summary = `📝 *Confirme os dados:*\n
Nome: ${conversation.data.name}
IP: ${conversation.data.ip}
Porta: ${conversation.data.port}
Usuário: ${conversation.data.user}
Senha: ${conversation.data.password}\n
Digite *1* para confirmar ou *0* para cancelar`;

        await sock.sendMessage(jid, { text: summary });
        break;

      case 'confirm':
        if (body === '1') {
          const result = await sshManager.addSSHServer(conversation.data);
          await sock.sendMessage(jid, { text: result.message });
        } else {
          await sock.sendMessage(jid, { text: '❌ Adição de servidor cancelada' });
        }
        delete conversations[jid]; // Encerra conversação
        break;

      default:
        delete conversations[jid];
        await sock.sendMessage(jid, { text: '❌ Conversação reiniciada' });
    }
  },

  async processAddPlanConversation(conversation, body, jid, sock) {
    switch (conversation.step) {
      case 'name':
        conversation.data.name = body.trim();
        conversation.step = 'days';
        await sock.sendMessage(jid, { text: '⏱️ Agora digite a *duração em dias* do plano:' });
        break;

      case 'days':
        const days = body.trim();
        if (!/^\d+$/.test(days)) {
          throw new Error('Duração inválida! Use apenas números');
        }
        conversation.data.days = parseInt(days);
        conversation.step = 'price';
        await sock.sendMessage(jid, { text: '💰 Digite o *preço do plano* (apenas números):' });
        break;

      case 'price':
        const price = body.trim();
        if (!/^\d+$/.test(price)) {
          throw new Error('Preço inválido! Use apenas números');
        }
        conversation.data.price = parseInt(price);
        conversation.step = 'confirm';
        const summary = `📝 *Confirme os dados do plano:*\n
Nome: ${conversation.data.name}
Duração: ${conversation.data.days} dias
Preço: ${conversation.data.price} Reais\n
Digite *1* para confirmar ou *0* para cancelar`;

        await sock.sendMessage(jid, { text: summary });
        break;

      case 'confirm':
        if (body === '1') {
          const result = planManager.addPlan(conversation.data);
          await sock.sendMessage(jid, { text: result.message });
        } else {
          await sock.sendMessage(jid, { text: '❌ Adição de plano cancelada' });
        }
        delete conversations[jid]; // Encerra conversação
        break;

      default:
        delete conversations[jid];
        await sock.sendMessage(jid, { text: '❌ Conversação reiniciada' });
    }
  },

  async criar(msg, sock) {
    const [username, days] = msg.message.conversation.split(' ').slice(1);

    if (!username || !days) {
      return 'Formato incorreto! Use: !criar <usuário> <dias>';
    }

    const server = sshManager.getAvailableServer();
    if (!server) return '❌ Nenhum servidor disponível no momento';

    const result = await sshManager.createSSHUser(username, parseInt(days), server.id);

    if (result.success) {
      return `✅ *Login Criado!*\n
IP: ${result.details.ip}
Porta: ${result.details.port}
Usuário: ${result.details.username}
Senha: ${result.details.password}
Validade: ${result.details.expiration}

⚠️ Mantenha suas credenciais em segurança!`;
    }
    return result.message;
  },

  async addserver(msg, sock) {
    const jid = msg.key.remoteJid;

    // Verifica se é administrador
    if (!isAdmin(jid)) {
      return '❌ Você não tem permissão para executar este comando.';
    }

    // Iniciar conversação
    if (!conversations[jid]) {
      conversations[jid] = {
        type: 'addserver',
        step: 'name',
        data: {}
      };
      await sock.sendMessage(jid, { text: '🔧 Vamos adicionar um novo servidor!\n\nDigite o *nome da máquina*:' });
      return;
    }

    await this.processMessage(msg, sock);
  },

  async addPlano(msg, sock) {
    const jid = msg.key.remoteJid;

    // Verifica se é administrador
    if (!isAdmin(jid)) {
      return '❌ Você não tem permissão para executar este comando.';
    }

    // Iniciar conversação
    if (!conversations[jid]) {
      conversations[jid] = {
        type: 'addplano',
        step: 'name',
        data: {}
      };
      await sock.sendMessage(jid, { text: '💼 Vamos adicionar um novo plano!\n\nDigite o *nome do plano*:' });
      return;
    }

    await this.processMessage(msg, sock);
  },

  async listarPlanos(msg, sock) {
    const plans = planManager.getPlans();

    if (!plans || plans.length === 0) {
      return '❌ Nenhum plano cadastrado no momento.';
    }

    let message = '📊 *PLANOS DISPONÍVEIS*\n\n';
    plans.forEach((plan, index) => {
      message += `${index + 1}: ${plan.name} - ${plan.price} Reais (${plan.days} dias)\n`;
    });

    message += '\nPara escolher um plano, digite apenas o número correspondente.';

    return message;
  },

  async escolherPlano(msg, sock) {
    const jid = msg.key.remoteJid;
    const planIndex = parseInt(msg.message.conversation) - 1;

    const plans = planManager.getPlans();

    if (!plans || planIndex < 0 || planIndex >= plans.length) {
      return '❌ Número de plano inválido. Use !planos para ver os planos disponíveis.';
    }

    const selectedPlan = plans[planIndex];

    // Iniciar fluxo de pagamento
    if (!conversations[jid]) {
      conversations[jid] = {
        type: 'payment',
        step: 'email',
        data: {
          selectedPlan
        }
      };
      await sock.sendMessage(jid, { 
        text: '📧 Para gerar o PIX, por favor digite seu *email*:'
      });
      return;
    }

    await this.processMessage(msg, sock);
  },

  async revogar(msg, sock) {
    const jid = msg.key.remoteJid;

    // Verifica se é administrador
    if (!isAdmin(jid)) {
      return '❌ Você não tem permissão para executar este comando.';
    }

    const [username, serverId] = msg.message.conversation.split(' ').slice(1);
    if (!username || !serverId) {
      return 'Formato incorreto! Use: !revogar <usuário> <server-id>';
    }

    const result = await sshManager.revokeSSHUser(username, serverId);
    return result.message;
  },

  servidores() {
    const servers = sshManager.servers.map(server => `
🖥️ *${server.name}*
IP: ${server.ip}
Porta: ${server.port}
Usuários: ${server.currentUsers}/${server.maxUsers}
Status: ${server.status === 'active' ? '✅ Ativo' : '❌ Inativo'}
ID: ${server.id}
    `).join('\n');

    return servers || 'Nenhum servidor cadastrado';
  },

  ajuda() {
    return `📝 *Comandos Disponíveis:*\n
!planos - Listar planos disponíveis
!addplano - Adicionar novo plano (admin)
!addserver - Adicionar novo servidor (admin)
!revogar <user> <server-id> - Revogar acesso (admin)
!servidores - Listar servidores disponíveis
!ajuda - Mostrar esta mensagem`;
  }
};

module.exports = commands;
