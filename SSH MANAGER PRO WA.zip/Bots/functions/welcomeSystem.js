class WelcomeSystem {
  constructor() {
    this.welcomeMessage = `
👋 *Olá, seja bem-vindo ao Bot da SSH MANAGER PRO!*

Adquira a melhor internet ilimitada do Brasil. 
Lembre-se de que eu sou um bot e responderei apenas aos comandos abaixo:

*MEUS COMANDOS* 👇

!testegratis - teste Grátis de 1hora
!planos - Ver planos disponíveis
!suporte - Falar com atendente humano
!aplicativo - Baixar nosso aplicativo

*Digite um dos comandos acima para continuar!*
    `;
  }

  // Retorna a mensagem de boas-vindas
  getWelcomeMessage() {
    return this.welcomeMessage;
  }
}

module.exports = new WelcomeSystem();