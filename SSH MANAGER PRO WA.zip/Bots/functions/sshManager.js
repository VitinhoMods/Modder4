const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { Client } = require('ssh2');
const { generateRandomPassword } = require('./utils');
const schedule = require('node-schedule');

class SSHManager {
  constructor() {
    this.serversFile = path.join(__dirname, '../data/servers.json');
    this.servers = this.loadServers();
    this.usersFile = path.join(__dirname, '../data/users.json');
    this.users = this.loadUsers();

    // Agenda a limpeza de usuários expirados a cada hora
    schedule.scheduleJob('0 * * * *', () => {
      this.cleanupExpiredUsers();
    });
  }

  // Carrega os servidores do arquivo JSON
  loadServers() {
    try {
      if (fs.existsSync(this.serversFile)) {
        return JSON.parse(fs.readFileSync(this.serversFile, 'utf8'));
      }
      return [];
    } catch (error) {
      console.error('Erro ao carregar servidores:', error);
      return [];
    }
  }

  // Carrega os usuários do arquivo JSON
  loadUsers() {
    try {
      if (fs.existsSync(this.usersFile)) {
        return JSON.parse(fs.readFileSync(this.usersFile, 'utf8'));
      }
      return [];
    } catch (error) {
      console.error('Erro ao carregar usuários:', error);
      return [];
    }
  }

  // Salva os servidores no arquivo JSON
  saveServers() {
    fs.writeFileSync(this.serversFile, JSON.stringify(this.servers, null, 2));
  }

  // Salva os usuários no arquivo JSON
  saveUsers() {
    fs.writeFileSync(this.usersFile, JSON.stringify(this.users, null, 2));
  }

  // Testa a conexão SSH com um servidor
  async testSSHConnection(server) {
    return new Promise((resolve) => {
      const conn = new Client();

      conn.on('ready', () => {
        conn.end();
        resolve(true);
      })
        .on('error', (error) => {
          console.error('Erro na conexão SSH:', error);
          resolve(false);
        })
        .connect({
          host: server.ip,
          port: server.port || 22,
          username: server.user,
          password: server.password
        });
    });
  }

  // Adiciona um novo servidor SSH
  async addSSHServer(serverData) {
    try {
      const server = {
        id: uuidv4(),
        name: serverData.name,
        ip: serverData.ip,
        port: serverData.port || 22,
        user: serverData.user,
        password: serverData.password,
        maxUsers: serverData.maxUsers || 50,
        currentUsers: 0,
        status: 'inactive',
        createdAt: new Date().toISOString()
      };

      // Testa a conexão antes de adicionar
      const connectionValid = await this.testSSHConnection(server);
      if (!connectionValid) throw new Error('Credenciais SSH inválidas ou porta incorreta');

      server.status = 'active';
      this.servers.push(server);
      this.saveServers();

      return {
        success: true,
        message: `✅ Servidor *${server.name}* (${server.ip}:${server.port}) adicionado com sucesso!`,
        serverId: server.id
      };
    } catch (error) {
      return {
        success: false,
        message: `❌ Erro ao adicionar servidor: ${error.message}`
      };
    }
  }

  // Cria um novo usuário SSH utilizando apenas o método chpasswd
  async createSSHUser(username, days, serverId) {
    try {
      const server = this.servers.find(s => s.id === serverId);
      if (!server) throw new Error('Servidor não encontrado');

      if (server.currentUsers >= server.maxUsers) {
        throw new Error('Limite de usuários atingido no servidor');
      }

      // Gera uma senha de 8 caracteres
      const password = generateRandomPassword(4).toString();
      console.log(`Senha gerada: ${password}`);

      const expirationDate = new Date();
      expirationDate.setDate(expirationDate.getDate() + days);

      // Adiciona o usuário à lista de usuários
      const userId = uuidv4();
      this.users.push({
        id: userId,
        username,
        password,
        serverId,
        expirationDate: expirationDate.toISOString(),
        status: 'active'
      });
      this.saveUsers();

      return new Promise((resolve, reject) => {
        const conn = new Client();

        conn.on('ready', async () => {
          try {
            // Cria o usuário sem diretório home e sem shell de login
            await this.execCommand(conn, `sudo useradd -M -s /bin/false ${username}`);

            // Define a senha utilizando chpasswd
            await this.execCommand(conn, `echo "${username}:${password}" | sudo chpasswd`);

            // Define a data de expiração do usuário
            const formattedDate = expirationDate.toISOString().split('T')[0];
            await this.execCommand(conn, `sudo usermod -e ${formattedDate} ${username}`);

            // Verifica se o usuário foi criado corretamente
            const checkUser = await this.execCommand(conn, `getent passwd ${username}`);
            console.log(`Usuário criado: ${checkUser}`);

            // Atualiza o contador de usuários
            server.currentUsers++;
            this.saveServers();

            conn.end();
            resolve({
              success: true,
              details: {
                ip: server.ip,
                port: server.port,
                username,
                password,
                expiration: expirationDate.toLocaleDateString('pt-BR'),
                serverId: server.id
              }
            });
          } catch (error) {
            conn.end();
            reject(error);
          }
        })
          .on('error', (error) => {
            reject(new Error(`Erro na conexão SSH: ${error.message}`));
          })
          .connect({
            host: server.ip,
            port: server.port || 22,
            username: server.user,
            password: server.password
          });
      });

    } catch (error) {
      console.error('Erro ao criar usuário SSH:', error);
      return {
        success: false,
        message: `❌ Erro ao criar usuário: ${error.message}`
      };
    }
  }

  // Executa um comando no servidor via SSH
  execCommand(conn, command) {
    return new Promise((resolve, reject) => {
      console.log(`Executando comando: ${command}`);

      conn.exec(command, (err, stream) => {
        if (err) {
          console.error(`Erro ao executar comando: ${err.message}`);
          return reject(err);
        }

        let output = '';
        let errorOutput = '';

        stream.on('close', (code) => {
          console.log(`Comando concluído com código: ${code}`);
          console.log(`Saída: ${output}`);

          if (code === 0 || code === undefined) {
            resolve(output);
          } else {
            console.error(`Erro na saída: ${errorOutput}`);
            reject(new Error(`Comando falhou com código ${code}: ${errorOutput}`));
          }
        })
          .on('data', (data) => {
            output += data.toString();
          })
          .stderr.on('data', (data) => {
            errorOutput += data.toString();
            console.error(`STDERR: ${data.toString()}`);
          });
      });
    });
  }

  // Retorna um servidor disponível
  getAvailableServer() {
    return this.servers.find(server => 
      server.status === 'active' && 
      server.currentUsers < server.maxUsers
    );
  }

  // Revoga o acesso de um usuário SSH
  async revokeSSHUser(username, serverId) {
    try {
      const server = this.servers.find(s => s.id === serverId);
      if (!server) throw new Error('Servidor não encontrado');

      return new Promise((resolve, reject) => {
        const conn = new Client();

        conn.on('ready', async () => {
          try {
            // Remove o usuário do servidor
            await this.execCommand(conn, `sudo userdel -r ${username}`);
            server.currentUsers = Math.max(0, server.currentUsers - 1);
            this.saveServers();

            // Remove o usuário da lista
            this.users = this.users.filter(u => u.username !== username);
            this.saveUsers();

            conn.end();
            resolve({
              success: true,
              message: `✅ Usuário ${username} revogado com sucesso!`
            });
          } catch (error) {
            conn.end();
            reject(error);
          }
        })
          .on('error', (error) => {
            reject(new Error(`Erro na conexão SSH: ${error.message}`));
          })
          .connect({
            host: server.ip,
            port: server.port || 22,
            username: server.user,
            password: server.password
          });
      });

    } catch (error) {
      return {
        success: false,
        message: `❌ Erro ao revogar usuário: ${error.message}`
      };
    }
  }

  // Limpa usuários cujo período de teste expirou
  async cleanupExpiredUsers() {
    try {
      const now = new Date();
      const expiredUsers = this.users.filter(user => {
        const expiration = new Date(user.expirationDate);
        return expiration <= now;
      });

      if (expiredUsers.length === 0) {
        console.log('Nenhum usuário expirado para limpar.');
        return;
      }

      console.log(`Removendo ${expiredUsers.length} usuário(s) expirado(s)...`);

      const promises = expiredUsers.map(async (user) => {
        const server = this.servers.find(s => s.id === user.serverId);
        if (!server) {
          console.error(`Servidor não encontrado para o usuário: ${user.username}`);
          return;
        }

        return new Promise((resolve, reject) => {
          const conn = new Client();

          conn.on('ready', async () => {
            try {
              // Remove o usuário do servidor
              await this.execCommand(conn, `sudo userdel -r ${user.username}`);
              console.log(`Usuário removido: ${user.username}`);

              // Remove o usuário da lista
              this.users = this.users.filter(u => u.id !== user.id);
              this.saveUsers();

              server.currentUsers = Math.max(0, server.currentUsers - 1);
              this.saveServers();

              conn.end();
              resolve();
            } catch (error) {
              conn.end();
              reject(error);
            }
          })
            .on('error', (error) => {
              reject(new Error(`Erro na conexão SSH: ${error.message}`));
            })
            .connect({
              host: server.ip,
              port: server.port || 22,
              username: server.user,
              password: server.password
            });
        });
      });

      await Promise.all(promises);
      console.log('Limpeza concluída com sucesso.');

    } catch (error) {
      console.error('Erro ao limpar usuários expirados:', error);
    }
  }
}

module.exports = new SSHManager();
