const fs = require('fs');
const path = require('path');
const schedule = require('node-schedule');

class TrialManager {
  constructor() {
    this.trialsFile = path.join(__dirname, '../data/trials.json');
    this.trials = this.loadTrials();
    this.initExpirationCheck();
  }

  // Carrega os testes do arquivo JSON
  loadTrials() {
    try {
      if (fs.existsSync(this.trialsFile)) {
        return JSON.parse(fs.readFileSync(this.trialsFile, 'utf8'));
      }
      return {};
    } catch (error) {
      console.error('Erro ao carregar trials:', error);
      return {};
    }
  }

  // Salva os testes no arquivo JSON
  saveTrials() {
    fs.writeFileSync(this.trialsFile, JSON.stringify(this.trials, null, 2));
  }

  // Verifica se o usuário pode solicitar um novo teste
  canRequestTrial(jid) {
    const trialData = this.trials[jid] || {};
    const now = Date.now();
    const cooldown = 48 * 60 * 60 * 1000; // 48 horas em milissegundos

    if (!trialData.lastTrial) return true;
    return (now - trialData.lastTrial) >= cooldown;
  }

  // Obtém o tempo restante do cooldown
  getRemainingCooldown(jid) {
    const trialData = this.trials[jid] || {};
    if (!trialData.lastTrial) return 0;

    const now = Date.now();
    const elapsed = now - trialData.lastTrial;
    return Math.max(0, (48 * 60 * 60 * 1000) - elapsed);
  }

  // Registra um novo teste
  registerTrial(jid) {
    const expirationTime = Date.now() + (60 * 60 * 1000); // Expira em 1 hora
    this.trials[jid] = {
      lastTrial: Date.now(),
      active: true,
      expirationTime: expirationTime
    };

    // Agenda a remoção do teste após 1 hora
    const removeTrial = (jid) => {
      delete this.trials[jid];
      this.saveTrials();
      console.log(`Teste para ${jid} foi removido.`);
    };

    const job = schedule.scheduleJob(expirationTime, () => {
      removeTrial(jid);
    });

    // Armazena o job para que possa ser cancelado se necessário
    this.trials[jid].job = job;

    this.saveTrials();
  }

  // Inicializa o check de expiração
  initExpirationCheck() {
    // Verifica a expiração a cada 10 minutos
    schedule.scheduleJob('*/10 * * * *', () => {
      const now = Date.now();
      for (const jid in this.trials) {
        const trial = this.trials[jid];
        if (trial.expirationTime <= now) {
          delete this.trials[jid];
          this.saveTrials();
          console.log(`Teste para ${jid} expirou e foi removido.`);
        }
      }
    });
  }
}

module.exports = new TrialManager();
