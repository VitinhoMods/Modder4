
const path = require("path");
const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");
const readline = require("readline");
const pino = require("pino");
const commands = require("./functions/botCommands");
const UserManager = require("./functions/userManager");
const WelcomeSystem = require("./functions/welcomeSystem");

const fs = require('fs');
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir);
}

const question = (string) => {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(string, resolve));
};

async function connect() {
  const { state, saveCreds } = await useMultiFileAuthState(
    path.resolve(__dirname, "auth")
  );

  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    printQRInTerminal: false,
    version,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: ["Ubuntu", "Chrome", "1.0.0"],
    markOnlineOnConnect: true,
  });

  if (!sock.authState.creds.registered) {
    let phoneNumber = await question("Informe o número com código do país (ex: 5511999999999): ");
    phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

    if (!phoneNumber) throw new Error("Número inválido!");

    const code = await sock.requestPairingCode(phoneNumber);
    console.log(`\nCódigo de pareamento: ${code}\n`);
  }

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut;

      console.log("Conexão fechada. Reconectando...");
      if (shouldReconnect) connect();
    } else if (connection === "open") {
      console.log("✅ Conectado com sucesso!");
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const userNumber = jid.replace(/@.*/, '');
    const body = msg.message.conversation 
      || msg.message.extendedTextMessage?.text 
      || '';

    try {
      if (UserManager.isUserIgnored(userNumber)) {
        return;
      }

      if (commands.isInConversation(jid)) {
        await commands.processMessage(msg, sock);
        return;
      }

      let response = '';

      if (body.toLowerCase() === '!suporte') {
        UserManager.ignoreUser(userNumber, 24);
        response = `
🛑 *Você foi direcionado ao suporte humano!*

Nossa equipe entrará em contato em breve. 
Por favor, *não envie mais mensagens* neste período de 24 horas para evitar conflitos no atendimento.
        `;
      }
      else if (body.startsWith('!criar')) {
        response = await commands.criar(msg, sock);
      }
      else if (body.startsWith('!addserver')) {
        response = await commands.addserver(msg, sock);
      }
      else if (body.startsWith('!revogar')) {
        response = await commands.revogar(msg, sock);
      }
      else if (body === '!servidores') {
        response = commands.servidores();
      }
      else if (body === '!ajuda' || body === '!help') {
        response = commands.ajuda();
      }
      else if (body === '!ping') {
        response = '🏓 Pong!';
      }
      else if (body === '!testegratis') {
        response = await commands.testeGratis(msg, sock);
      }
      else if (body === '!planos') {
        response = await commands.listarPlanos(msg, sock);
      }
      else if (body.startsWith('!addplano')) {
        response = await commands.addPlano(msg, sock);
      }
      else if (/^\d+$/.test(body)) {
        response = await commands.escolherPlano(msg, sock);
      }
      else if (!body.startsWith('!') && !/^\d+$/.test(body)) {
        response = WelcomeSystem.getWelcomeMessage();
      }

      if (response) {
        await sock.sendMessage(jid, { text: response });
      }
    } catch (error) {
      console.error('Erro:', error);
      await sock.sendMessage(jid, { text: '❌ Ocorreu um erro no processamento' });
    }
  });

  return sock;
}

connect()
  .then(() => console.log("Bot pronto para uso!"))
  .catch((err) => console.error("Erro na conexão:", err));
